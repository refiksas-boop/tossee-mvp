<?php
/**
 * Plugin Name: Tossee Report System
 * Description: Chat report system for Tossee
 * Version: 1.0.3
 * Author: Tossee Team
 * Requires PHP: 7.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Constants
define('TOSSEE_VERSION', '1.0.3');
define('TOSSEE_DIR', plugin_dir_path(__FILE__));
define('TOSSEE_URL', plugin_dir_url(__FILE__));

/**
 * Activation - create database tables
 */
register_activation_hook(__FILE__, 'tossee_activate');

function tossee_activate() {
    global $wpdb;
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    $charset = $wpdb->get_charset_collate();

    // 1. Users table
    $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}tossee_users (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        tossee_id VARCHAR(40) NOT NULL,
        username VARCHAR(60) NOT NULL,
        email VARCHAR(120) NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        dob DATE NOT NULL,
        photo LONGTEXT NOT NULL,
        is_blocked TINYINT(1) DEFAULT 0,
        block_reason TEXT NULL,
        blocked_at DATETIME NULL,
        blocked_by BIGINT(20) NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY (email),
        UNIQUE KEY (tossee_id)
    ) $charset;";
    dbDelta($sql);

    // 2. Reports table
    $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}tossee_reports (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        reporter_id VARCHAR(40) NOT NULL,
        reported_user_id VARCHAR(40) NOT NULL,
        report_reason VARCHAR(100) NOT NULL,
        additional_details TEXT NULL,
        report_status VARCHAR(20) DEFAULT 'pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        reviewed_at DATETIME NULL,
        reviewed_by BIGINT(20) NULL,
        PRIMARY KEY (id)
    ) $charset;";
    dbDelta($sql);

    // 3. Admin messages table
    $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}tossee_admin_messages (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id VARCHAR(40) NOT NULL,
        admin_id BIGINT(20) UNSIGNED NOT NULL,
        message TEXT NOT NULL,
        is_read TINYINT(1) DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset;";
    dbDelta($sql);

    // 4. Notifications table
    $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}tossee_notifications (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        notification_type VARCHAR(50) NOT NULL,
        reference_id BIGINT(20) UNSIGNED NOT NULL,
        message TEXT NOT NULL,
        is_read TINYINT(1) DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset;";
    dbDelta($sql);

    // 5. Settings table
    $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}tossee_settings (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        setting_key VARCHAR(100) NOT NULL,
        setting_value TEXT NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY (setting_key)
    ) $charset;";
    dbDelta($sql);

    // Insert default setting
    $wpdb->query("INSERT IGNORE INTO {$wpdb->prefix}tossee_settings (setting_key, setting_value) VALUES ('report_button_enabled', '1')");

    flush_rewrite_rules();
}

/**
 * Include files after WordPress loads
 */
add_action('plugins_loaded', 'tossee_load_files');

function tossee_load_files() {
    // Load API
    $api_file = TOSSEE_DIR . 'includes/api.php';
    if (file_exists($api_file)) {
        require_once $api_file;
    }

    // Load admin menu (only in admin)
    if (is_admin()) {
        $menu_file = TOSSEE_DIR . 'includes/admin-menu.php';
        if (file_exists($menu_file)) {
            require_once $menu_file;
        }
    }
}

/**
 * Chat shortcode
 */
add_shortcode('tossee_chat', 'tossee_chat_shortcode');

function tossee_chat_shortcode() {
    ob_start();
    $chat_file = TOSSEE_DIR . 'templates/chat.php';
    if (file_exists($chat_file)) {
        include $chat_file;
    } else {
        echo '<p>Chat template not found.</p>';
    }
    return ob_get_clean();
}

/**
 * Deactivation
 */
register_deactivation_hook(__FILE__, 'tossee_deactivate');

function tossee_deactivate() {
    flush_rewrite_rules();
}
