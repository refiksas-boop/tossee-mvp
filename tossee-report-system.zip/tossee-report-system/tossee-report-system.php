<?php
/**
 * Plugin Name: Tossee Report System
 * Description: Chat report system for Tossee
 * Version: 1.0.2
 * Author: Tossee Team
 * Requires PHP: 7.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Constants
define('TOSSEE_VERSION', '1.0.2');
define('TOSSEE_DIR', plugin_dir_path(__FILE__));
define('TOSSEE_URL', plugin_dir_url(__FILE__));

/**
 * Activation - create database tables
 */
register_activation_hook(__FILE__, 'tossee_activate');

function tossee_activate() {
    global $wpdb;

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    $charset = $wpdb->get_charset_collate();

    // Reports table
    $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}tossee_reports (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        reporter_id VARCHAR(40) NOT NULL,
        reported_user_id VARCHAR(40) NOT NULL,
        report_reason VARCHAR(100) NOT NULL,
        additional_details TEXT NULL,
        report_status VARCHAR(20) NOT NULL DEFAULT 'pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        reviewed_at DATETIME NULL,
        reviewed_by BIGINT(20) NULL,
        PRIMARY KEY (id)
    ) $charset;";
    dbDelta($sql);

    // Settings table
    $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}tossee_settings (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        setting_key VARCHAR(100) NOT NULL,
        setting_value TEXT NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY (setting_key)
    ) $charset;";
    dbDelta($sql);

    // Insert default setting
    $wpdb->query("INSERT IGNORE INTO {$wpdb->prefix}tossee_settings (setting_key, setting_value) VALUES ('report_button_enabled', '1')");

    flush_rewrite_rules();
}

/**
 * Include files after WordPress loads
 */
add_action('plugins_loaded', 'tossee_load_files');

function tossee_load_files() {
    // Load API
    $api_file = TOSSEE_DIR . 'includes/api.php';
    if (file_exists($api_file)) {
        require_once $api_file;
    }

    // Load admin menu (only in admin)
    if (is_admin()) {
        $menu_file = TOSSEE_DIR . 'includes/admin-menu.php';
        if (file_exists($menu_file)) {
            require_once $menu_file;
        }
    }
}

/**
 * Chat shortcode
 */
add_shortcode('tossee_chat', 'tossee_chat_shortcode');

function tossee_chat_shortcode() {
    ob_start();
    $chat_file = TOSSEE_DIR . 'templates/chat.php';
    if (file_exists($chat_file)) {
        include $chat_file;
    } else {
        echo '<p>Chat template not found.</p>';
    }
    return ob_get_clean();
}

/**
 * Deactivation
 */
register_deactivation_hook(__FILE__, 'tossee_deactivate');

function tossee_deactivate() {
    flush_rewrite_rules();
}
