<?php
/**
 * Plugin Name: Tossee Report System
 * Plugin URI: https://tossee.com
 * Description: Complete chat report system for Tossee - includes chat interface, admin panel, user blocking, messaging, and report management
 * Version: 1.0.1
 * Author: Tossee Development Team
 * Author URI: https://tossee.com
 * License: GPL v2 or later
 * Text Domain: tossee-report
 * Requires at least: 5.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Define plugin constants
define('TOSSEE_REPORT_VERSION', '1.0.1');
define('TOSSEE_REPORT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('TOSSEE_REPORT_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Activation hook - create database tables
 */
function tossee_report_activate() {
    global $wpdb;
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    $charset_collate = $wpdb->get_charset_collate();

    // Create users table
    $table_name = $wpdb->prefix . 'tossee_users';
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        tossee_id VARCHAR(40) NOT NULL,
        username VARCHAR(60) NOT NULL,
        email VARCHAR(120) NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        dob DATE NOT NULL,
        photo LONGTEXT NOT NULL,
        is_blocked TINYINT(1) NOT NULL DEFAULT 0,
        block_reason TEXT NULL,
        blocked_at DATETIME NULL,
        blocked_by BIGINT(20) UNSIGNED NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY email (email),
        UNIQUE KEY tossee_id (tossee_id),
        KEY is_blocked (is_blocked)
    ) $charset_collate;";
    dbDelta($sql);

    // Create reports table
    $table_name = $wpdb->prefix . 'tossee_reports';
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        reporter_id VARCHAR(40) NOT NULL,
        reported_user_id VARCHAR(40) NOT NULL,
        report_reason VARCHAR(100) NOT NULL,
        additional_details TEXT NULL,
        report_status VARCHAR(20) NOT NULL DEFAULT 'pending',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        reviewed_at DATETIME NULL,
        reviewed_by BIGINT(20) UNSIGNED NULL,
        PRIMARY KEY (id),
        KEY reporter_id (reporter_id),
        KEY reported_user_id (reported_user_id),
        KEY report_status (report_status)
    ) $charset_collate;";
    dbDelta($sql);

    // Create admin messages table
    $table_name = $wpdb->prefix . 'tossee_admin_messages';
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id VARCHAR(40) NOT NULL,
        admin_id BIGINT(20) UNSIGNED NOT NULL,
        message TEXT NOT NULL,
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY admin_id (admin_id),
        KEY is_read (is_read)
    ) $charset_collate;";
    dbDelta($sql);

    // Create settings table
    $table_name = $wpdb->prefix . 'tossee_settings';
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        setting_key VARCHAR(100) NOT NULL,
        setting_value TEXT NOT NULL,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY setting_key (setting_key)
    ) $charset_collate;";
    dbDelta($sql);

    // Insert default settings
    $wpdb->replace(
        $wpdb->prefix . 'tossee_settings',
        array('setting_key' => 'report_button_enabled', 'setting_value' => '1'),
        array('%s', '%s')
    );

    // Create notifications table
    $table_name = $wpdb->prefix . 'tossee_notifications';
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        notification_type VARCHAR(50) NOT NULL,
        reference_id BIGINT(20) UNSIGNED NOT NULL,
        message TEXT NOT NULL,
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY notification_type (notification_type),
        KEY is_read (is_read)
    ) $charset_collate;";
    dbDelta($sql);

    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'tossee_report_activate');

/**
 * Deactivation hook
 */
function tossee_report_deactivate() {
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'tossee_report_deactivate');

/**
 * Load plugin files
 */
function tossee_report_init() {
    // Include API endpoints
    if (file_exists(TOSSEE_REPORT_PLUGIN_DIR . 'includes/api.php')) {
        require_once TOSSEE_REPORT_PLUGIN_DIR . 'includes/api.php';
    }

    // Include admin menu (only in admin)
    if (is_admin() && file_exists(TOSSEE_REPORT_PLUGIN_DIR . 'includes/admin-menu.php')) {
        require_once TOSSEE_REPORT_PLUGIN_DIR . 'includes/admin-menu.php';
    }
}
add_action('plugins_loaded', 'tossee_report_init');

/**
 * Register chat page shortcode
 */
function tossee_chat_shortcode() {
    ob_start();
    if (file_exists(TOSSEE_REPORT_PLUGIN_DIR . 'templates/chat.php')) {
        include TOSSEE_REPORT_PLUGIN_DIR . 'templates/chat.php';
    }
    return ob_get_clean();
}
add_shortcode('tossee_chat', 'tossee_chat_shortcode');
