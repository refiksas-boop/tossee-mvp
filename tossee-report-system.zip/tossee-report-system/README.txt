=== Tossee Report System ===
Contributors: Tossee Team
Tags: reports, moderation, chat, admin, user-management
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Complete chat report system with user blocking, direct messaging, and comprehensive admin controls.

== Description ==

Tossee Report System provides a complete solution for managing chat reports, including:

* Chat Report System - Users can report inappropriate behavior
* Admin Dashboard - View and manage all reports
* User Blocking - Block/unblock users with reasons
* Direct Messaging - Send messages to users
* Button Controls - Enable/disable report button globally
* Notifications - Real-time notification system
* Statistics Dashboard - View report statistics

== Installation ==

1. Upload plugin ZIP via WordPress admin or extract to `/wp-content/plugins/tossee-report-system`
2. Activate the plugin through the 'Plugins' menu
3. Database tables will be created automatically
4. Access admin panel from WordPress dashboard under "Tossee Reports"
5. Create a page and add shortcode [tossee_chat] for chat interface

== Chat Page Setup ==

Method 1: Create a WordPress page and add shortcode: [tossee_chat]
Method 2: Access directly via: https://your-site.com/?tossee_chat=1

== Frequently Asked Questions ==

= Where is the admin panel? =
After activation, go to WordPress Dashboard → Tossee Reports

= How do I add the chat page? =
Create a new page and add the shortcode: [tossee_chat]

= Can I customize report reasons? =
Currently includes three predefined reasons. Future versions will allow customization.

== Changelog ==

= 1.0.1 =
* Fixed activation issues
* Improved error handling
* Added shortcode support for chat page

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.1 =
Fixes activation issues and adds shortcode support
