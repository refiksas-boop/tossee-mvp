=== Tossee Report System ===
Version: 1.0.2
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.0
License: GPLv2

== Description ==

Simple chat report system for Tossee.

== Installation ==

1. Upload ZIP via Plugins > Add New
2. Activate plugin
3. Access via Dashboard > Tossee Reports
4. Add [tossee_chat] shortcode to a page for chat interface

== Changelog ==

= 1.0.2 =
* Simplified activation process
* Fixed critical errors
* Minimal dependencies

= 1.0.0 =
* Initial release
