<?php
/**
 * Admin Menu
 */

if (!defined('ABSPATH')) {
    exit;
}

// Add menu
add_action('admin_menu', 'tossee_admin_menu');

function tossee_admin_menu() {
    add_menu_page(
        'Tossee Reports',
        'Tossee Reports',
        'manage_options',
        'tossee-reports',
        'tossee_reports_page',
        'dashicons-warning',
        25
    );
}

// Reports page
function tossee_reports_page() {
    $template = TOSSEE_DIR . 'templates/admin-reports.php';
    if (file_exists($template)) {
        include $template;
    } else {
        echo '<div class="wrap"><h1>Tossee Reports</h1><p>Template not found.</p></div>';
    }
}

// Admin notices
add_action('admin_notices', 'tossee_admin_notices');

function tossee_admin_notices() {
    global $wpdb;
    $table = $wpdb->prefix . 'tossee_reports';

    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
        return;
    }

    $count = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE report_status = 'pending'");

    if ($count > 0) {
        echo '<div class="notice notice-warning is-dismissible">';
        echo '<p><strong>Tossee:</strong> ' . $count . ' pending report(s). ';
        echo '<a href="' . admin_url('admin.php?page=tossee-reports') . '">View</a></p>';
        echo '</div>';
    }
}
