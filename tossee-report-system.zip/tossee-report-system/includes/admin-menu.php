<?php
/**
 * Admin Menu for Tossee Report System
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Add admin menu items
 */
function tossee_add_admin_menu() {
    add_menu_page(
        'Tossee Reports',           // Page title
        'Tossee Reports',           // Menu title
        'manage_options',           // Capability
        'tossee-reports',           // Menu slug
        'tossee_reports_page',      // Callback function
        'dashicons-warning',        // Icon
        25                          // Position
    );

    add_submenu_page(
        'tossee-reports',
        'All Reports',
        'All Reports',
        'manage_options',
        'tossee-reports',
        'tossee_reports_page'
    );

    add_submenu_page(
        'tossee-reports',
        'Chat Page',
        'Chat Page',
        'manage_options',
        'tossee-chat-page',
        'tossee_chat_page_info'
    );
}
add_action('admin_menu', 'tossee_add_admin_menu');

/**
 * Reports page callback
 */
function tossee_reports_page() {
    if (file_exists(TOSSEE_REPORT_PLUGIN_DIR . 'templates/admin-reports.php')) {
        include TOSSEE_REPORT_PLUGIN_DIR . 'templates/admin-reports.php';
    } else {
        echo '<div class="wrap"><h1>Tossee Reports</h1><p>Template file not found.</p></div>';
    }
}

/**
 * Chat page info callback
 */
function tossee_chat_page_info() {
    ?>
    <div class="wrap">
        <h1>Tossee Chat Page</h1>
        <div class="card">
            <h2>How to Add Chat Page</h2>
            <p>Create a new page in WordPress and add this shortcode:</p>
            <p><code>[tossee_chat]</code></p>
            <hr>
            <h3>Or use direct URL:</h3>
            <p><strong><?php echo home_url('/?tossee_chat=1'); ?></strong></p>
        </div>
    </div>
    <?php
}

/**
 * Add admin notice for unread reports
 */
function tossee_admin_notices() {
    global $wpdb;
    $reports_table = $wpdb->prefix . 'tossee_reports';

    // Check if table exists
    if ($wpdb->get_var("SHOW TABLES LIKE '$reports_table'") != $reports_table) {
        return;
    }

    $pending_count = $wpdb->get_var("SELECT COUNT(*) FROM $reports_table WHERE report_status = 'pending'");

    if ($pending_count > 0) {
        ?>
        <div class="notice notice-warning is-dismissible">
            <p><strong>Tossee Reports:</strong> You have <?php echo $pending_count; ?> pending report(s) to review.
            <a href="<?php echo admin_url('admin.php?page=tossee-reports'); ?>">View Reports</a></p>
        </div>
        <?php
    }
}
add_action('admin_notices', 'tossee_admin_notices');

/**
 * Template redirect for chat page
 */
function tossee_template_redirect() {
    if (isset($_GET['tossee_chat'])) {
        if (file_exists(TOSSEE_REPORT_PLUGIN_DIR . 'templates/chat.php')) {
            include TOSSEE_REPORT_PLUGIN_DIR . 'templates/chat.php';
            exit;
        }
    }
}
add_action('template_redirect', 'tossee_template_redirect');
