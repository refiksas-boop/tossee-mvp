<?php
/**
 * Plugin Name: Tossee Report System
 * Description: Simple chat report system
 * Version: 1.0.4
 * Author: Tossee Team
 */

if (!defined('ABSPATH')) exit;

// Activation - create tables
register_activation_hook(__FILE__, function() {
    global $wpdb;
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    $charset = $wpdb->get_charset_collate();

    // Reports table
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}tossee_reports (
        id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        reporter_id VARCHAR(40) NOT NULL,
        reported_user_id VARCHAR(40) NOT NULL,
        report_reason VARCHAR(100) NOT NULL,
        additional_details TEXT NULL,
        report_status VARCHAR(20) DEFAULT 'pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $charset");
});

// Admin menu
add_action('admin_menu', function() {
    add_menu_page(
        'Tossee Reports',
        'Tossee Reports',
        'manage_options',
        'tossee-reports',
        function() {
            echo '<div class="wrap"><h1>Tossee Reports</h1>';
            echo '<p>Report system is active!</p>';

            global $wpdb;
            $reports = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}tossee_reports ORDER BY created_at DESC LIMIT 20");

            if ($reports) {
                echo '<table class="wp-list-table widefat fixed striped">';
                echo '<thead><tr><th>ID</th><th>Reporter</th><th>Reported User</th><th>Reason</th><th>Status</th><th>Date</th></tr></thead><tbody>';
                foreach ($reports as $r) {
                    echo '<tr>';
                    echo '<td>' . $r->id . '</td>';
                    echo '<td>' . esc_html($r->reporter_id) . '</td>';
                    echo '<td>' . esc_html($r->reported_user_id) . '</td>';
                    echo '<td>' . esc_html($r->report_reason) . '</td>';
                    echo '<td>' . esc_html($r->report_status) . '</td>';
                    echo '<td>' . esc_html($r->created_at) . '</td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
            } else {
                echo '<p>No reports yet.</p>';
            }

            echo '</div>';
        },
        'dashicons-warning'
    );
});

// REST API - Submit report
add_action('rest_api_init', function() {
    register_rest_route('tossee/v1', '/report', array(
        'methods' => 'POST',
        'callback' => function($request) {
            global $wpdb;

            $data = json_decode($request->get_body(), true);

            if (empty($data['reporter_id']) || empty($data['reported_user_id']) || empty($data['report_reason'])) {
                return new WP_Error('missing_fields', 'Missing required fields', array('status' => 400));
            }

            $wpdb->insert(
                $wpdb->prefix . 'tossee_reports',
                array(
                    'reporter_id' => sanitize_text_field($data['reporter_id']),
                    'reported_user_id' => sanitize_text_field($data['reported_user_id']),
                    'report_reason' => sanitize_text_field($data['report_reason']),
                    'additional_details' => isset($data['additional_details']) ? sanitize_textarea_field($data['additional_details']) : null
                )
            );

            return array('success' => true, 'message' => 'Report submitted');
        },
        'permission_callback' => '__return_true'
    ));
});
